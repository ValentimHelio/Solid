﻿namespace Dip.Model
{
    interface DbProduct
    {

        string GetProductById(string id);

    }
}
